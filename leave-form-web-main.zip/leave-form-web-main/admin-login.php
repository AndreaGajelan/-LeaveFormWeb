<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="admin-login.css">
</head>
<body>
  <section class="container">
    <header class="leave-admin-login">Admin Login</header>
    <form action="#" class="form">
      <div class="username-tf">
        <input type="text" placeholder="Username" required/>
      </div>
      <div class="password-tf">
        <input type="password" placeholder="Password" required/>
      </div>
      <div class="login-btn-container">
        <button class="login-btn">Login</button>
      </div>
    </form>
  </section>
</body>
</html>