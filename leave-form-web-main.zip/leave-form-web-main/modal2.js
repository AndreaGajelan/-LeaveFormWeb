function togglePopup2() {
    document.getElementById("popup-2").classList.toggle("active");
}