<?php
// Include PHPMailer autoloader
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $recipient = $_POST['recipient'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Set mailer to use SMTP
        $mail->isSMTP();

        // SMTP configuration
        $mail->Host = 'smtp.gmail.com';  // Replace with your SMTP server host
        $mail->SMTPAuth = true;  // Enable SMTP authentication
        $mail->Username = 'andreahgajelan@gmail.com';  // Replace with your email address
        $mail->Password = 'rwgg pmjp yizq grfa';  // Replace with your email password
        $mail->SMTPSecure = 'tls'; // Enable TLS encryption (optional)
        $mail->Port = 587; // TCP port to connect to (may vary with your provider)

        // Set the From and Reply-To headers
        $mail->setFrom('andreahgajelan@gmail.com', 'Andrea Gajelan');
        $mail->addAddress($recipient); // Add recipient email address
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send email
        $mail->send();
        $status = "Email sent successfully!";
    } catch (Exception $e) {
        $status = "Failed to send email. Error: {$mail->ErrorInfo}";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email</title>
</head>
<body>
    <h2>Send Email</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="recipient">Recipient:</label><br>
        <input type="email" id="recipient" name="recipient" required><br><br>

        <label for="subject">Subject:</label><br>
        <input type="text" id="subject" name="subject" required><br><br>

        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" cols="50" required></textarea><br><br>

        <input type="submit" value="Send Email">
    </form>

    <?php if(isset($status)) { ?>
        <p><?php echo $status; ?></p>
    <?php } ?>
</body>
</html>
