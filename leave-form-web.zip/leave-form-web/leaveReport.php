<?php
require 'db.php';

// Check if user is logged in
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

// Fetch leave summary for all employees
$summaryQuery = "
    SELECT jcleavetable.empId, 
           CONCAT(emp.fName, ' ', emp.mName, ' ', emp.lName, ' ', emp.sName) AS fullName,
           SUM(CASE WHEN jcleavetable.leaveType = 'Sick Leave' THEN 1 ELSE 0 END) AS sickLeaveCount,
           SUM(CASE WHEN jcleavetable.leaveType = 'Vacation Leave' THEN 1 ELSE 0 END) AS vacationLeaveCount,
           SUM(CASE WHEN jcleavetable.leaveType = 'Paternity Leave' THEN 1 ELSE 0 END) AS paternityLeaveCount,
           SUM(CASE WHEN jcleavetable.leaveType = 'Parental Leave' THEN 1 ELSE 0 END) AS parentalLeaveCount,
           SUM(CASE WHEN jcleavetable.leaveType = 'Bereavement Leave' THEN 1 ELSE 0 END) AS bereavementLeaveCount,
           SUM(CASE WHEN jcleavetable.leaveType NOT IN ('Sick Leave', 'Vacation Leave', 'Paternity Leave', 'Parental Leave', 'Bereavement Leave') THEN 1 ELSE 0 END) AS othersCount
    FROM jcleavetable
    JOIN emp ON jcleavetable.empId = emp.empId
    GROUP BY jcleavetable.empId, fullName
";

$summaryResult = mysqli_query($conn, $summaryQuery);

// Check if query execution was successful
if (!$summaryResult) {
    die('Error fetching leave summary: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Leave Summary Report</title>
<link rel="stylesheet" href="empDashboard.css">
<style>
    .back-btn {
        margin: 20px;
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        text-decoration: none;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .back-btn:hover {
        background-color: #45a049;
    }
    .download-btn {
        margin: 20px;
        padding: 10px 20px;
        background-color: #008CBA;
        color: white;
        text-decoration: none;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .download-btn:hover {
        background-color: #006C9E;
    }
    .summary-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 16px; /* Adjust font size as needed */
    }
    .summary-table th, .summary-table td {
        border: 1px solid black;
        padding: 10px;
        text-align: left;
    }
    .summary-table th {
        background-color: #f2f2f2;
    }
</style>
</head>
<body>

<header class="header-container">
  <div class="logo">
    <img src="logo.png" alt="Logo">
  </div>
  <div class="left-navigations">
    <button class="logout-btn"><a href="logout.php">Logout</a></button>
  </div>
</header>

<section class="table-container">
    <div class="button-container">
        <button class="back-btn" onclick="window.location.href='admin-panel.php'">Back to Admin Panel</button>
        <button class="download-btn" onclick="downloadCSV()">Download CSV</button>
    </div>
    <div class="table">
        <table class="summary-table">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Full Name</th>
                    <th>Sick Leave</th>
                    <th>Vacation Leave</th>
                    <th>Paternity Leave</th>
                    <th>Parental Leave</th>
                    <th>Bereavement Leave</th>
                    <th>Others</th>
                    <th>Total Leaves</th>
                    <th>Remaining Days</th> <!-- New column header -->
                </tr>
            </thead>
            <tbody>
            <?php
                if ($summaryResult && mysqli_num_rows($summaryResult) > 0) {
                    while ($summaryRow = mysqli_fetch_assoc($summaryResult)) {
                        // Calculate total leaves
                        $totalLeaves = $summaryRow['sickLeaveCount'] + $summaryRow['vacationLeaveCount'] + $summaryRow['paternityLeaveCount'] + $summaryRow['parentalLeaveCount'] + $summaryRow['bereavementLeaveCount'] + $summaryRow['othersCount'];
                        // Calculate remaining days
                        $remainingDays = 18 - $totalLeaves; // Assuming the limit is 18 days

                        ?>
                        <tr>
                            <td><?php echo $summaryRow['empId']; ?></td>
                            <td><?php echo $summaryRow['fullName']; ?></td>
                            <td><?php echo $summaryRow['sickLeaveCount']; ?></td>
                            <td><?php echo $summaryRow['vacationLeaveCount']; ?></td>
                            <td><?php echo $summaryRow['paternityLeaveCount']; ?></td>
                            <td><?php echo $summaryRow['parentalLeaveCount']; ?></td>
                            <td><?php echo $summaryRow['bereavementLeaveCount']; ?></td>
                            <td><?php echo $summaryRow['othersCount']; ?></td>
                            <td><?php echo $totalLeaves; ?></td> <!-- Total leaves -->
                            <td><?php echo $remainingDays; ?></td> <!-- Remaining days -->
                        </tr>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='10'>No leave summary available.</td></tr>";
                }
            ?>
            </tbody>
        </table>
    </div>
</section>

<script>
    function downloadCSV() {
        var table = document.querySelector('.summary-table');
        var rows = Array.from(table.querySelectorAll('tr'));

        var csvContent = "data:text/csv;charset=utf-8,";
        csvContent += rows.map(function(row) {
            var rowData = Array.from(row.querySelectorAll('th, td'));
            return rowData.map(function(cell) {
                return cell.textContent;
            }).join(',');
        }).join('\n');

        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "leave_summary.csv");
        document.body.appendChild(link);
        link.click();
    }
</script>

</body>
</html>
