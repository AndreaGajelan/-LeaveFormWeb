<?php
// Include PHPSpreadsheet autoloader
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection settings
$dsn = 'mysql:host=localhost;dbname=mydatabase';
$username = 'username';
$password = 'password';

try {
    // Connect to the database
    $pdo = new PDO($dsn, $username, $password);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit();
}

// Fetch data from the database
$stmt = $pdo->prepare("SELECT * FROM my_table");
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Create a new Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Add headers
$column = 'A';
foreach ($data[0] as $key => $value) {
    $sheet->setCellValue($column . '1', $key);
    $column++;
}

// Add data
$row = 2;
foreach ($data as $row_data) {
    $column = 'A';
    foreach ($row_data as $value) {
        $sheet->setCellValue($column . $row, $value);
        $column++;
    }
    $row++;
}

// Save Excel file
$writer = new Xlsx($spreadsheet);
$filename = 'data.xlsx';
$writer->save($filename);

// Provide download link
echo "<a href='$filename'>Download Excel File</a>";
?>
