<?php
require 'db.php';

// Check if action and id parameters are set in the URL
if (isset($_GET['action'], $_GET['id'])) { // Changed from 'empId' to 'id'
    // Retrieve action and id from GET parameters
    $action = $_GET['action'];
    $id = $_GET['id']; // Changed from 'empId' to 'id'

    // Determine status based on action
    $status = ($action === 'approve') ? 'Approved' : 'Rejected';
    
    date_default_timezone_set('Asia/Manila');
    $remarks = date('Y-m-d H:i:s'); // Set remarks to current timestamp

    // Update the database
    $sql = "UPDATE jcleavetable SET updateStatus = ?, remarks = ? WHERE id = ?"; // Changed from 'empId' to 'id'
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssi", $status, $remarks, $id); // Bind 'id' instead of 'empId'
        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Status updated successfully!'); window.location.href='https://mail.google.com/'; </script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }
} else {
    // If action or id is not provided in the URL, display an error message or redirect to an error page
    echo "Invalid request";
}
?>
